﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class AddJobs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnAddJob_Click(object sender, EventArgs e)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["zzCS321_7ConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);

        String sql = "INSERT INTO Jobs (CompanyName, JobDescription, Industry, HoursRange, Experience, CompanyEmail, CompanyPhone, HiringDate)" +
                      "Values (@CompanyName, @JobDescription, @Industry, @HoursRange, @Experience, @CompanyEmail, @CompanyPhone, @HiringDate)";
        SqlCommand cmd = new SqlCommand(sql, con);

        //Parameters
        cmd.Parameters.Add("@CompanyName", System.Data.SqlDbType.VarChar, 50);
        cmd.Parameters["@CompanyName"].Value = txtCompanyName.Text;
        cmd.Parameters.Add("@JobDescription", System.Data.SqlDbType.VarChar, 200);
        cmd.Parameters["@JobDescription"].Value = txtJobDescription.Text;
        cmd.Parameters.Add("@Industry", System.Data.SqlDbType.VarChar, 50);
        cmd.Parameters["@Industry"].Value = ddlIndustries.SelectedValue;
        cmd.Parameters.Add("@HoursRange", System.Data.SqlDbType.VarChar, 50);
        cmd.Parameters["@HoursRange"].Value = rblHoursRange.SelectedValue;
        cmd.Parameters.Add("@Experience", System.Data.SqlDbType.VarChar, 50);
        cmd.Parameters["@Experience"].Value = ddlExperience.SelectedValue;
        cmd.Parameters.Add("@CompanyEmail", System.Data.SqlDbType.VarChar, 50);
        cmd.Parameters["@CompanyEmail"].Value = txtContactEmail.Text;
        cmd.Parameters.Add("@CompanyPhone", System.Data.SqlDbType.VarChar, 50);
        cmd.Parameters["@CompanyPhone"].Value = txtPhone.Text;
        cmd.Parameters.Add("@HiringDate", System.Data.SqlDbType.Date);
        cmd.Parameters["@HiringDate"].Value = txtHiringDate.Text;

        try
        {

            con.Open();//open the connection

            //Execute the reader returns SqlDataReader
            cmd.ExecuteNonQuery();
        }

        catch
        {
            lblError.Text = "Error updating Categories!<br />";
        }
        finally
        {
            con.Close();
        }

    }
  
protected void rblHoursRange_SelectedIndexChanged(object sender, EventArgs e)
{

}
protected void txtJobDescription_TextChanged(object sender, EventArgs e)
{

}
}