﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class AnonSurvey : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmitSurvery_Click(object sender, EventArgs e)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["zzCS321_7ConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);

        //prepeare command
        String sql = "INSERT INTO SurveyInfo (Name, Email, FieldOfInterest, YearOfGraduation, DegreeField) VALUES ('@fullName', '@email', '@FOI', '@YOG', '@DegreeField')";
        SqlCommand cmd = new SqlCommand(sql, con);

        //add parameter
        cmd.Parameters.AddWithValue("fullName", txtName.Text);
        cmd.Parameters.AddWithValue("email", txtEmail.Text);
        cmd.Parameters.AddWithValue("FOI", ddlIndustry.SelectedValue);
        cmd.Parameters.AddWithValue("YOG", txtGraduationYear.Text);
        cmd.Parameters.AddWithValue("DegreeField", txtDegreeField.Text);

        try
        {

            con.Open();//open the connection

            //Execute the reader returns SqlDataReader
            cmd.ExecuteNonQuery();
        }

        catch (System.Data.SqlClient.SqlException ex)
        {

            string msg = "Insert Error:";

            msg += ex.Message;

            throw new Exception(msg);



        }

        finally
        {

            con.Close();

        }
    }
}