﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//Includes for sending mail
using System.Net.Mail;
using System.Net;

public partial class ContactUs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

protected void btnSend_Click(object sender, EventArgs e)
{
    try
    {
        MailMessage msg = new MailMessage();
        msg.To.Add(new MailAddress("simondemertzis@gmail.com"));
        msg.From = new MailAddress(txtEmail.Text);
        msg.Subject = txtSubject.Text;
        msg.Body = txtName.Text + "" + txtMessage.Value;
        SmtpClient client = new SmtpClient();
        client.Host = "smtp.gmail.com"; //Place your smtp server in quotation marks (i.e. “smtp.live.com”)
        client.Port = 587; // Place your smtp port here, i.e. hotmail’s smtp port is 587
        client.Credentials = new NetworkCredential("simondemertzis@gmail.com", "5808Springdale");
        client.EnableSsl = true;
        client.Send(msg);
    }
    catch
    {
        lblError.Text = "error sending message";
    }
}
protected void btnReset_Click(object sender, EventArgs e)
{

}
}