﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class SearchJobs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        String jobDescription = "";
        int index = 0;
        index = GridView1.SelectedIndex;
        GridViewRow row = GridView1.Rows[index];
        jobDescription = row.Cells[1].Text;

        String connectionString = WebConfigurationManager.ConnectionStrings["zzCS321_7ConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);

        //prepeare command
        String sql = "SELECT * FROM Jobs WHERE JobDescription = @JobDescription";//Include Parameter
        SqlCommand cmd = new SqlCommand(sql, con);

        //add parameter(pay attention to this)
        cmd.Parameters.Add("@JobDescription", System.Data.SqlDbType.VarChar, 200);
        cmd.Parameters["@JobDescription"].Value = jobDescription;


        try
        {

            con.Open();//open the connection

            //Execute the reader returns SqlDataReader
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                lblCompanyName.Text = reader["CompanyName"].ToString();
                lblJobDescription.Text = reader["JobDescription"].ToString();
                lblIndustry.Text = reader["Industry"].ToString();
                lblHours.Text = reader["HoursRange"].ToString();
                lblExperienceNeeded.Text = reader["Experience"].ToString();
                lblContactEmail.Text = reader["CompanyEmail"].ToString();
                lblCompanyPhone.Text = reader["CompanyPhone"].ToString();
                lblHiringDate.Text = reader["HiringDate"].ToString();


            }
            reader.Close();

        }

        catch
        {
            
        }
        finally
        {
            con.Close();
        }
        
    }
}