//
//  AppDelegate.h
//  portInter
//
//  Created by NEIU Developer on 12/10/14.
//  Copyright (c) 2014 NEIU Developer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
