﻿CREATE TABLE [dbo].[Table]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Project Name] TEXT NOT NULL, 
    [Task Type] TEXT NOT NULL, 
    [Task Assigned To] TEXT NOT NULL, 
    [Deadline] DATE NULL
)
