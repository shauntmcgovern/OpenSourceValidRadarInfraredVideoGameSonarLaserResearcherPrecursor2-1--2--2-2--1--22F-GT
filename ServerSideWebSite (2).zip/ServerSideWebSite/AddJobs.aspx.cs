﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class AddJobs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            loadJobs();
        }
    }
    private void loadJobs()
    {

        //String connectionString = WebConfigurationManager.ConnectionStrings["zzCS321_7ConnectionString"].ConnectionString;
        //SqlConnection con = new SqlConnection(connectionString);

        //String sql = "SELECT * FROM Jobs";
        //SqlCommand cmd = new SqlCommand(sql, con);

        //try
        //{

        //    con.Open();//open the connection

        //    //Execute the reader returns SqlDataReader
        //    SqlDataReader reader = cmd.ExecuteReader();

        //    //Cycle through the records
        //    lbxJobs.DataSource = reader;
        //    lbxJobs.DataValueField = "JobDescription";
        //    lbxJobs.DataTextField = "JobDescription";
              lbxJobs.DataBind();
        //}

        //catch
        //{
        //    lblError.Text = "Error loading Jobs!<br />";
        //}

        //finally
        //{
        //    con.Close();
        //}


    }
    protected void btnAddJob_Click(object sender, EventArgs e)
    {
        String connectionString = WebConfigurationManager.ConnectionStrings["zzCS321_7ConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);

        String sql = "INSERT INTO Jobs (CompanyName, JobDescription, Industry, HoursRange, Experience, CompanyEmail, CompanyPhone, HiringDate)" +
                      "Values (@CompanyName, @JobDescription, @Industry, @HoursRange, @Experience, @CompanyEmail, @CompanyPhone, @HiringDate)";
        SqlCommand cmd = new SqlCommand(sql, con);

        //Parameters
        cmd.Parameters.Add("@CompanyName", System.Data.SqlDbType.VarChar, 50);
        cmd.Parameters["@CompanyName"].Value = txtCompanyName.Text;
        cmd.Parameters.Add("@JobDescription", System.Data.SqlDbType.VarChar, 200);
        cmd.Parameters["@JobDescription"].Value = txtJobDescription.Text;
        cmd.Parameters.Add("@Industry", System.Data.SqlDbType.VarChar, 50);
        cmd.Parameters["@Industry"].Value = ddlIndustries.SelectedValue;
        cmd.Parameters.Add("@HoursRange", System.Data.SqlDbType.VarChar, 50);
        cmd.Parameters["@HoursRange"].Value = rblHoursRange.SelectedValue;
        cmd.Parameters.Add("@Experience", System.Data.SqlDbType.VarChar, 50);
        cmd.Parameters["@Experience"].Value = ddlExperience.SelectedValue;
        cmd.Parameters.Add("@CompanyEmail", System.Data.SqlDbType.VarChar, 50);
        cmd.Parameters["@CompanyEmail"].Value = txtContactEmail.Text;
        cmd.Parameters.Add("@CompanyPhone", System.Data.SqlDbType.VarChar, 50);
        cmd.Parameters["@CompanyPhone"].Value = txtPhone.Text;
        cmd.Parameters.Add("@HiringDate", System.Data.SqlDbType.Date);
        cmd.Parameters["@HiringDate"].Value = txtHiringDate.Text;

        try
        {

            con.Open();//open the connection

            //Execute the reader returns SqlDataReader
            cmd.ExecuteNonQuery();
        }

        catch
        {
            lblError.Text = "Error updating Categories!<br />";
        }
        finally
        {
            con.Close();
        }
        txtCompanyName.Text = "";
        ddlExperience.SelectedIndex = 0;
        txtJobDescription.Text = "";
        ddlIndustries.SelectedIndex = 0;
        txtPhone.Text = "";
        txtContactEmail.Text = "";
        rblHoursRange.SelectedIndex = 0;
        txtHiringDate.Text = "";
        loadJobs();

    }
  
protected void btnSelectJob_Click(object sender, EventArgs e)
{
        String connectionString = WebConfigurationManager.ConnectionStrings["zzCS321_7ConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(connectionString);

        //prepeare command
        String sql = "SELECT * FROM Jobs WHERE JobDescription = @JobDescription";//Include Parameter
        SqlCommand cmd = new SqlCommand(sql, con);

        //add parameter(pay attention to this)
        cmd.Parameters.Add("@JobDescription", System.Data.SqlDbType.VarChar, 200);
        cmd.Parameters["@JobDescription"].Value = lbxJobs.SelectedItem.Value;
    

        try
        {

            con.Open();//open the connection

            //Execute the reader returns SqlDataReader
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                txtCompanyName.Text = reader["CompanyName"].ToString();
                txtJobDescription.Text = reader["JobDescription"].ToString();
                ddlIndustries.SelectedValue = reader["Industry"].ToString();
                rblHoursRange.SelectedValue = reader["HoursRange"].ToString();
                ddlExperience.SelectedValue = reader["Experience"].ToString();
                txtContactEmail.Text = reader["CompanyEmail"].ToString();
                txtPhone.Text = reader["CompanyPhone"].ToString();
                txtHiringDate.Text = reader["HiringDate"].ToString();

                
            }
            reader.Close();
          
        }

        catch
        {
            lblError.Text = "Error selecting Categories!<br />";
        }
        finally
        {
            con.Close();
        }

        
    }

protected void btnDeleteJob_Click(object sender, EventArgs e)
{
    String connectionString = WebConfigurationManager.ConnectionStrings["zzCS321_7ConnectionString"].ConnectionString;
    SqlConnection con = new SqlConnection(connectionString);

    //prepeare command
    String sql = "DELETE FROM Jobs WHERE JobDescription = @JobDescription";
    SqlCommand cmd = new SqlCommand(sql, con);

    cmd.Parameters.Add("@JobDescription", System.Data.SqlDbType.VarChar, 50);
    cmd.Parameters["@JobDescription"].Value = lbxJobs.SelectedItem.Value;

    try
    {

        con.Open();//open the connection

        //Execute the reader returns SqlDataReader
        cmd.ExecuteNonQuery();
    }

    catch
    {
        lblError.Text = "Error updating Categories!<br />";
    }
    finally
    {
        con.Close();
    }
    txtCompanyName.Text = "";
    ddlExperience.SelectedIndex = 0;
    txtJobDescription.Text = "";
    ddlIndustries.SelectedIndex = 0;
    txtPhone.Text = "";
    txtContactEmail.Text = "";
    rblHoursRange.SelectedIndex = 0;
    txtHiringDate.Text = "";
    loadJobs();

}
protected void btnClear_Click(object sender, EventArgs e)
{
    txtCompanyName.Text = "";
    ddlExperience.SelectedIndex = 0;
    txtJobDescription.Text = "";
    ddlIndustries.SelectedIndex = 0;
    txtPhone.Text = "";
    txtContactEmail.Text = "";
    rblHoursRange.SelectedIndex = 0;
    txtHiringDate.Text = "";
   
}
protected void btnUpdateJob_Click(object sender, EventArgs e)
{
    String connectionString = WebConfigurationManager.ConnectionStrings["zzCS321_7ConnectionString"].ConnectionString;
    SqlConnection con = new SqlConnection(connectionString);

    //prepeare command
    String sql = "UPDATE Jobs SET CompanyName = @CompanyName, JobDescription = @JobDescription, Industry = @Industry, HoursRange = @HoursRange, Experience = @Experience, CompanyEmail = @CompanyEmail, CompanyPhone = @CompanyPhone, HiringDate = @HiringDate   WHERE JobDescription = @JobDescription";
    SqlCommand cmd = new SqlCommand(sql, con);

    //add parameter
    cmd.Parameters.Add("@CompanyName", System.Data.SqlDbType.VarChar, 50);
    cmd.Parameters["@CompanyName"].Value = txtCompanyName.Text;
    cmd.Parameters.Add("@JobDescription", System.Data.SqlDbType.VarChar, 200);
    cmd.Parameters["@JobDescription"].Value = txtJobDescription.Text;
    cmd.Parameters.Add("@Industry", System.Data.SqlDbType.VarChar, 50);
    cmd.Parameters["@Industry"].Value = ddlIndustries.SelectedValue;
    cmd.Parameters.Add("@HoursRange", System.Data.SqlDbType.VarChar, 50);
    cmd.Parameters["@HoursRange"].Value = rblHoursRange.SelectedValue;
    cmd.Parameters.Add("@Experience", System.Data.SqlDbType.VarChar, 50);
    cmd.Parameters["@Experience"].Value = ddlExperience.SelectedValue;
    cmd.Parameters.Add("@CompanyEmail", System.Data.SqlDbType.VarChar, 50);
    cmd.Parameters["@CompanyEmail"].Value = txtContactEmail.Text;
    cmd.Parameters.Add("@CompanyPhone", System.Data.SqlDbType.VarChar, 50);
    cmd.Parameters["@CompanyPhone"].Value = txtPhone.Text;
    cmd.Parameters.Add("@HiringDate", System.Data.SqlDbType.Date);
    cmd.Parameters["@HiringDate"].Value = txtHiringDate.Text;

    try
    {

        con.Open();//open the connection

        //Execute the reader returns SqlDataReader
        cmd.ExecuteNonQuery();
    }

    catch
    {
        lblError.Text = "Error updating Categories!<br />";
    }
    finally
    {
        con.Close();
    }
    loadJobs();
}
}